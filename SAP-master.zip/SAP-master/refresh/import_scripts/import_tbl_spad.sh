#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/import_spad.log /usr/sap/trans/refresh/scripts/import_SPAD
