#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/import_scot.log /usr/sap/trans/refresh/scripts/import_SCOT
