#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/import_sp01.log /usr/sap/trans/refresh/scripts/import_SP01
