#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/import_scc4.log /usr/sap/trans/refresh/scripts/import_T000
