#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/import_sm59.log /usr/sap/trans/refresh/scripts/import_SM59
