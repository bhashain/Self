#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/import_we20.log /usr/sap/trans/refresh/scripts/import_WE20
