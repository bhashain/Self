#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/import_TWPURLSVR.log /usr/sap/trans/refresh/scripts/import_TWPURLSVR
