#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/export_bd64.log /usr/sap/trans/refresh/scripts/export_BD64
