#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/export_scc4.log /usr/sap/trans/refresh/scripts/export_T000
