#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/export_spad.log /usr/sap/trans/refresh/scripts/export_SPAD
