#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/export_sm37.log /usr/sap/trans/refresh/scripts/export_SM37
