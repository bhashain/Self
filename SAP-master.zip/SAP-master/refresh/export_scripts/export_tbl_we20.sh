#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/export_WE20.log /usr/sap/trans/refresh/scripts/export_WE20
