#!/bin/sh
R3trans -w /usr/sap/trans/refresh/logs/export_TWPURLSVR.log /usr/sap/trans/refresh/scripts/export_TWPURLSVR
